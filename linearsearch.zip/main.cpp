/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;
int linearsearch(int lottery[],int size,int num);
int main(){
    int lottery[]={1,2,3,4,5,6,7,8,9};
    int size=sizeof(lottery)/sizeof(lottery[0]);
    int num;
    int index;
    cin>>num;
    index=linearsearch(lottery, size,num);
    if(index!=-1){
        cout<<num<<" is at index "<<index<<".";
    }else{
        cout<<"It's not present in array.";
    }
}

int linearsearch(int lottery[],int size,int element){
    for (int i=0;i<size;i++){
        if(lottery[i]==element){
            return i;
        }
       
    }
    return -1;
}
