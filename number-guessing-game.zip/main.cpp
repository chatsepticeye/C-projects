/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
    int num;
    int guess;
    int tries;
    cout<<"********************NUMBER GUESSING GAME************************************"<<endl;
    srand(time(NULL));
    num=rand()%10+1;
    
    do{
        cout<<"Enter your guess: "<<endl;
        cin>>guess;
        if(guess>num){
            cout<<"Too high!!"<<endl;
            tries++;
            
        }
        else if(guess<num){
            cout<<"Too low!!"<<endl;
            tries++;
        }
        else{
            cout<<"CORRECT!! no.of tries"<<tries<<endl;
        }
        
    }while(guess != num);
    return 0;
}
    
    