/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int fact(int num)
    {
    if(num<1){
        return 1;
    }
    else{
        return num*fact(num-1);
    }
}
int main()
{
    int n;
    cout<<"Enter the number: "<<endl;
    cin>>n;
    cout<<"The factorial of the number is :"<<fact(n)<<endl;
    
}